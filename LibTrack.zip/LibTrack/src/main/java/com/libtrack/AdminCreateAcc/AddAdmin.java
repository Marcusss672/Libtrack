package com.libtrack.AdminCreateAcc;

import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.libtrack.security.FirebaseInitializer;
import org.mindrot.jbcrypt.BCrypt;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class AddAdmin {
    
    public static void main(String[] args) {
        try {
            System.out.println("=== Firebase Admin Account Creator ===\n");
            
            // Initialize Firebase
            System.out.println("Initializing Firebase...");
            FirebaseInitializer.initialize();
            System.out.println("✓ Firebase initialized\n");
            
            Scanner scanner = new Scanner(System.in);
            
            System.out.print("Enter admin email: ");
            String email = scanner.nextLine().trim();
            
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            
            if (email.isEmpty() || password.isEmpty()) {
                System.err.println("✗ Email and password cannot be empty!");
                scanner.close();
                System.exit(1);
                return;
            }
            
            System.out.println("\nGenerating password hash...");
            String passwordHash = BCrypt.hashpw(password, BCrypt.gensalt(10));
            
            // Create admin data
            Map<String, Object> adminData = new HashMap<>();
            adminData.put("email", email);
            adminData.put("passwordHash", passwordHash);
            
            System.out.println("Saving to Firebase Realtime Database...");
            
            // Get reference
            DatabaseReference ref = FirebaseDatabase.getInstance()
                    .getReference("admins");
            
            String adminId = ref.push().getKey();
            
            if (adminId == null) {
                System.err.println("✗ Failed to generate admin ID");
                scanner.close();
                System.exit(1);
                return;
            }
            
            // Use CountDownLatch to wait for completion
            CountDownLatch latch = new CountDownLatch(1);
            final boolean[] success = {false};
            
            System.out.println("Writing to database path: admins/" + adminId);
            
            ref.child(adminId).setValue(adminData, new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(DatabaseError error, DatabaseReference ref) {
                    if (error != null) {
                        System.err.println("\n✗ Error saving admin!");
                        System.err.println("Error code: " + error.getCode());
                        System.err.println("Error message: " + error.getMessage());
                        System.err.println("Error details: " + error.getDetails());
                        
                        if (error.getCode() == DatabaseError.PERMISSION_DENIED) {
                            System.err.println("\nPermission denied! Please check Firebase rules:");
                            System.err.println("Go to Firebase Console → Realtime Database → Rules");
                            System.err.println("Set: { \"rules\": { \".read\": true, \".write\": true } }");
                        }
                    } else {
                        success[0] = true;
                        System.out.println("\n✓ Admin account created successfully!");
                        System.out.println("══════════════════════════════════");
                        System.out.println("Email: " + email);
                        System.out.println("Admin ID: " + adminId);
                        System.out.println("══════════════════════════════════");
                        System.out.println("\nYou can now login with these credentials.");
                    }
                    latch.countDown();
                }
            });
            
            // Wait for completion (max 15 seconds)
            System.out.println("Waiting for database write to complete...");
            boolean completed = latch.await(15, TimeUnit.SECONDS);
            
            if (!completed) {
                System.err.println("\n✗ Timeout! Database write took too long.");
                System.err.println("Possible causes:");
                System.err.println("1. No internet connection");
                System.err.println("2. Firebase rules blocking write");
                System.err.println("3. Invalid database URL");
            } else if (!success[0]) {
                System.err.println("\n✗ Database write failed. See error above.");
            }
            
            scanner.close();
            
            // Give a bit more time for async operations to complete
            Thread.sleep(1000);
            
            System.exit(success[0] ? 0 : 1);
            
        } catch (Exception e) {
            System.err.println("\n✗ Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}