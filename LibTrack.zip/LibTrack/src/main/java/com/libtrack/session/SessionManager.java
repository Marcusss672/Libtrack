package com.libtrack.session;

public class SessionManager {

    private static String adminUid;
    private static String adminEmail;

    private SessionManager() {}

    public static void saveSession(String uid, String email) {
        adminUid = uid;
        adminEmail = email;
    }

    public static boolean isLoggedIn() {
        return adminUid != null;
    }

    public static String getAdminUid() {
        return adminUid;
    }

    public static String getAdminEmail() {
        return adminEmail;
    }

    public static void clearSession() {
        adminUid = null;
        adminEmail = null;
    }
}
