package com.libtrack.controllers;

import com.google.firebase.database.*;
import com.libtrack.session.SessionManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.mindrot.jbcrypt.BCrypt;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label statusLabel;

    @FXML
    private Button loginButton;

    @FXML
    public void initialize() {
        System.out.println("LoginController initialized");
        
        if (statusLabel != null) {
            statusLabel.setText("");
            statusLabel.setVisible(false);
        }
    }

    @FXML
    private void handleLogin() {
        System.out.println("\n=== Login Attempt ===");
        
        // Disable button during login
        if (loginButton != null) {
            loginButton.setDisable(true);
        }

        String email = emailField.getText().trim();
        String password = passwordField.getText();

        System.out.println("Email entered: " + email);
        System.out.println("Password length: " + password.length());

        if (email.isEmpty() || password.isEmpty()) {
            System.out.println("Validation failed: Empty fields");
            showStatus("Please enter email and password", true);
            enableLoginButton();
            return;
        }

        // Show loading state
        showStatus("Authenticating...", false);
        System.out.println("Connecting to Firebase Realtime Database...");

        // Create timeout tracker
        AtomicBoolean callbackReceived = new AtomicBoolean(false);
        
        // Set 10 second timeout
        Timer timeoutTimer = new Timer();
        timeoutTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (!callbackReceived.get()) {
                    System.err.println("\n✗ TIMEOUT: No response from Firebase after 10 seconds");
                    System.err.println("Possible causes:");
                    System.err.println("1. Firebase Database Rules are blocking read access");
                    System.err.println("2. Database URL is incorrect");
                    System.err.println("3. No internet connection");
                    System.err.println("4. The 'admins' node doesn't exist in database");
                    
                    Platform.runLater(() -> {
                        showStatus("✗ Connection timeout. Check database settings.", true);
                        enableLoginButton();
                    });
                }
            }
        }, 10000); // 10 seconds

        try {
            DatabaseReference ref = FirebaseDatabase.getInstance()
                    .getReference("admins");

            System.out.println("Database reference created");
            System.out.println("Querying database...");

            ref.addListenerForSingleValueEvent(new ValueEventListener() {

                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    callbackReceived.set(true);
                    timeoutTimer.cancel();
                    
                    System.out.println("\n=== Firebase Callback Received ===");
                    System.out.println("Snapshot exists: " + snapshot.exists());
                    System.out.println("Number of admins: " + snapshot.getChildrenCount());

                    if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                        System.err.println("\n✗ ERROR: No admins found in database!");
                        System.err.println("Solution: Run AddAdmin.java to create an admin account");
                        System.err.println("Or manually add an admin in Firebase Console");
                        
                        Platform.runLater(() -> {
                            showStatus("✗ No admin accounts configured", true);
                            enableLoginButton();
                        });
                        return;
                    }

                    boolean emailFound = false;
                    boolean loginSuccessful = false;

                    for (DataSnapshot admin : snapshot.getChildren()) {
                        String adminKey = admin.getKey();
                        String dbEmail = admin.child("email").getValue(String.class);
                        String passwordHash = admin.child("passwordHash").getValue(String.class);

                        System.out.println("\nChecking admin:");
                        System.out.println("  Key: " + adminKey);
                        System.out.println("  Email: " + dbEmail);
                        System.out.println("  Has password hash: " + (passwordHash != null));

                        if (dbEmail == null || passwordHash == null) {
                            System.out.println("  Skipping - missing credentials");
                            continue;
                        }

                        if (email.equalsIgnoreCase(dbEmail)) {
                            emailFound = true;
                            System.out.println("  ✓ Email match found!");
                            
                            try {
                                System.out.println("  Verifying password...");
                                if (BCrypt.checkpw(password, passwordHash)) {
                                    System.out.println("  ✓ Password verified!");
                                    
                                    SessionManager.saveSession(adminKey, dbEmail);
                                    loginSuccessful = true;
                                    
                                    Platform.runLater(() -> {
                                        showStatus("✓ Login successful!", false);
                                        
                                        new Thread(() -> {
                                            try {
                                                Thread.sleep(1000);
                                                Platform.runLater(() -> navigateToDashboard());
                                            } catch (InterruptedException e) {
                                                e.printStackTrace();
                                            }
                                        }).start();
                                    });
                                    
                                    break;
                                } else {
                                    System.out.println("  ✗ Password verification failed");
                                }
                            } catch (Exception e) {
                                System.err.println("  ✗ Password check error: " + e.getMessage());
                                e.printStackTrace();
                            }
                            
                            break;
                        }
                    }

                    if (!loginSuccessful) {
                        System.out.println("\n=== Login Failed ===");
                        
                        final boolean finalEmailFound = emailFound;
                        Platform.runLater(() -> {
                            if (finalEmailFound) {
                                showStatus("✗ Incorrect password", true);
                            } else {
                                showStatus("✗ Email not found", true);
                            }
                            enableLoginButton();
                        });
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    callbackReceived.set(true);
                    timeoutTimer.cancel();
                    
                    System.err.println("\n=== Firebase Error ===");
                    System.err.println("Error code: " + error.getCode());
                    System.err.println("Error message: " + error.getMessage());
                    System.err.println("Error details: " + error.getDetails());
                    
                    // Specific error handling
                    String userMessage;
                    if (error.getCode() == DatabaseError.PERMISSION_DENIED) {
                        userMessage = "✗ Access denied";
                        System.err.println("\n✗ PERMISSION DENIED!");
                        System.err.println("Solution:");
                        System.err.println("1. Go to Firebase Console");
                        System.err.println("2. Realtime Database → Rules");
                        System.err.println("3. Change to: { \"rules\": { \".read\": true, \".write\": true } }");
                    } else if (error.getCode() == DatabaseError.NETWORK_ERROR) {
                        userMessage = "✗ Network error";
                        System.err.println("Check your internet connection");
                    } else {
                        userMessage = "✗ Database error";
                    }
                    
                    error.toException().printStackTrace();
                    
                    Platform.runLater(() -> {
                        showStatus(userMessage, true);
                        enableLoginButton();
                    });
                }
            });

        } catch (Exception e) {
            callbackReceived.set(true);
            timeoutTimer.cancel();
            
            System.err.println("\n=== Exception in handleLogin ===");
            e.printStackTrace();
            Platform.runLater(() -> {
                showStatus("✗ Connection error", true);
                enableLoginButton();
            });
        }
    }

    private void showStatus(String message, boolean isError) {
        System.out.println("UI Status: " + message);
        
        if (statusLabel != null) {
            statusLabel.setText(message);
            statusLabel.setStyle(
                    isError
                            ? "-fx-text-fill: #C41E3A; -fx-font-size: 14px; -fx-font-weight: 600;"
                            : "-fx-text-fill: #2E7D32; -fx-font-size: 14px; -fx-font-weight: 600;"
            );
            statusLabel.setVisible(true);
            statusLabel.setManaged(true);
        }
    }

    private void enableLoginButton() {
        if (loginButton != null) {
            loginButton.setDisable(false);
        }
    }

    private void navigateToDashboard() {
        System.out.println("Navigating to dashboard...");
        
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/libtrack/admin-dashboard.fxml")
            );
            Parent root = loader.load();

            Stage stage = (Stage) emailField.getScene().getWindow();
            stage.setScene(new Scene(root, 1200, 700));
            stage.setTitle("LibTrack - Admin Dashboard");
            
            System.out.println("Dashboard loaded successfully");

        } catch (Exception e) {
            System.err.println("Failed to load dashboard:");
            e.printStackTrace();
            showStatus("✗ Failed to load dashboard", true);
            enableLoginButton();
        }
    }
}