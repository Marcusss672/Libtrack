package com.libtrack;

import com.libtrack.security.FirebaseInitializer;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) {
        try {
            // Initialize Firebase FIRST
            FirebaseInitializer.initialize();
            
            // Then load FXML
            Parent root = FXMLLoader.load(
                    getClass().getResource("/com/libtrack/login.fxml")
            );

            stage.setTitle("LibTrack - Admin Login");
            stage.setScene(new Scene(root, 900, 600));
            stage.setResizable(false);
            stage.show();

        } catch (Exception e) {
            System.err.println("Error starting application: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}