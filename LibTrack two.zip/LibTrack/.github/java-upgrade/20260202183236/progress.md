# Upgrade Progress

  ### ❗ Generate Upgrade Plan
  - [[View Log]](logs\1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to get git status for c:\Users\Marcus Marcelino\OneDrive - Mapúa University\Documents\LibTrack: fatal: not a git repository (or any of the parent directories): .git
  </details>