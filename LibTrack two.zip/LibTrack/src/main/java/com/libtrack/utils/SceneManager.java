package com.libtrack.utils;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.Window;

public class SceneManager {

    public static void navigate(javafx.scene.Node currentNode, String fxmlPath, String title, int width, int height) {
        try {
            // Load FXML
            System.out.println("Loading FXML: " + fxmlPath);
            FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource(fxmlPath));
            Parent root = loader.load();
            System.out.println("FXML loaded successfully");
            
            // Get stage - with multiple fallback options
            Stage stage = null;
            
            // Try 1: Get from current node
            if (currentNode != null) {
                Scene scene = currentNode.getScene();
                if (scene != null) {
                    Window window = scene.getWindow();
                    if (window instanceof Stage) {
                        stage = (Stage) window;
                        System.out.println("Got stage from current node");
                    }
                }
            }
            
            // Try 2: Get from all windows
            if (stage == null) {
                System.out.println("Current node scene was null, getting stage from window list");
                for (Window window : Window.getWindows()) {
                    if (window instanceof Stage && window.isShowing()) {
                        stage = (Stage) window;
                        System.out.println("Got stage from window list");
                        break;
                    }
                }
            }
            
            // Try 3: Create new stage (shouldn't happen in normal flow)
            if (stage == null) {
                System.out.println("Creating new stage");
                stage = new Stage();
            }
            
            // Set scene and show
            stage.setScene(new Scene(root, width, height));
            stage.setTitle(title);
            stage.setResizable(false);
            stage.show();
            
            System.out.println("Successfully navigated to: " + fxmlPath);
            
        } catch (Exception e) {
            System.err.println("Navigation failed to: " + fxmlPath);
            e.printStackTrace();
        }
    }
}