package com.libtrack.security;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

import java.io.InputStream;

public class FirebaseInitializer {

    private static boolean initialized = false;

    public static void initialize() {
        if (initialized) {
            System.out.println("Firebase already initialized");
            return;
        }

        try {
            System.out.println("Attempting to initialize Firebase...");
            
            InputStream serviceAccount =
                    FirebaseInitializer.class
                            .getResourceAsStream("/firebase/libtrack-firebase-key.json");

            if (serviceAccount == null) {
                throw new RuntimeException(
                    "Firebase credentials file not found at: /firebase/libtrack-firebase-key.json"
                );
            }

            System.out.println("Credentials file found");

            // ✓ CORRECTED DATABASE URL
            String databaseUrl = "https://libtrack-system-default-rtdb.firebaseio.com";
            
            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .setDatabaseUrl(databaseUrl)
                    .build();

            System.out.println("Firebase Database URL: " + databaseUrl);
            FirebaseApp.initializeApp(options);
            initialized = true;

            System.out.println("✓ Firebase initialized successfully");

        } catch (Exception e) {
            System.err.println("✗ Firebase initialization failed:");
            e.printStackTrace();
            throw new RuntimeException("Firebase initialization failed: " + e.getMessage(), e);
        }
    }
}