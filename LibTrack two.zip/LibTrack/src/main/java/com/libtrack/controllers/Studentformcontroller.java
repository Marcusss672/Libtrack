package com.libtrack.controllers;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.libtrack.utils.SceneManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Studentformcontroller {

    @FXML private TextField nameField;
    @FXML private TextField studentNoField;
    @FXML private TextField programYearField;
    @FXML private ComboBox<String> termCombo;
    @FXML private TextField schoolYearField;
    @FXML private TextField dateField;
    @FXML private VBox itemsContainer;
    @FXML private Label totalAmountLabel;

    private List<ItemRow> itemRows = new ArrayList<>();
    private double totalAmount = 0.0;

    // Fee pricing map
    private Map<String, Double> feePrices = new HashMap<>();

    @FXML
    public void initialize() {
        System.out.println("StudentFormController initialized");
        
        // Initialize fee prices
        feePrices.put("Printing – Black Text", 4.0);
        feePrices.put("Printing – Black Graphics", 6.0);
        feePrices.put("Printing – Color Text", 10.0);
        feePrices.put("Printing – Color Graphics", 15.0);
        feePrices.put("Library Fine", 10.0);
        feePrices.put("Outside Researcher Fee", 50.0);
        feePrices.put("Alumni Fee", 50.0);
        feePrices.put("Referral Letter", 50.0);
        
        // Set current date
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        dateField.setText(today.format(formatter));
        
        // Add first item row
        addItemRow();
    }

    @FXML
    private void handleAddItem() {
        addItemRow();
    }

    private void addItemRow() {
        ItemRow itemRow = new ItemRow();
        itemRows.add(itemRow);
        itemsContainer.getChildren().add(itemRow.getContainer());
        updateTotal();
    }

    private void removeItemRow(ItemRow itemRow) {
        itemRows.remove(itemRow);
        itemsContainer.getChildren().remove(itemRow.getContainer());
        updateTotal();
    }

    private void updateTotal() {
        totalAmount = 0.0;
        for (ItemRow row : itemRows) {
            totalAmount += row.getAmount();
        }
        totalAmountLabel.setText(String.format("₱%.2f", totalAmount));
    }

    @FXML
    private void handleSubmit() {
        // Validate inputs
        if (!validateInputs()) {
            return;
        }

        // Prepare transaction data
        Map<String, Object> transactionData = new HashMap<>();
        transactionData.put("fullName", nameField.getText().trim());
        transactionData.put("studentNo", studentNoField.getText().trim());
        transactionData.put("programYear", programYearField.getText().trim());
        transactionData.put("term", termCombo.getValue());
        transactionData.put("schoolYear", schoolYearField.getText().trim());
        transactionData.put("transactionDate", dateField.getText());
        transactionData.put("totalAmount", String.format("%.2f", totalAmount));
        transactionData.put("submittedAt", System.currentTimeMillis());
        
        // Add items
        List<Map<String, Object>> items = new ArrayList<>();
        for (ItemRow row : itemRows) {
            Map<String, Object> item = new HashMap<>();
            item.put("itemDescription", row.getItemDescription());
            item.put("quantity", row.getQuantity());
            item.put("amount", row.getAmount());
            items.add(item);
        }
        transactionData.put("items", items);

        // Save to Firebase
        saveToFirebase(transactionData);
    }

    private boolean validateInputs() {
        if (nameField.getText().trim().isEmpty()) {
            showError("Please enter your name");
            return false;
        }
        if (studentNoField.getText().trim().isEmpty()) {
            showError("Please enter your student number");
            return false;
        }
        if (programYearField.getText().trim().isEmpty()) {
            showError("Please enter your program/year");
            return false;
        }
        if (termCombo.getValue() == null) {
            showError("Please select a term");
            return false;
        }
        if (schoolYearField.getText().trim().isEmpty()) {
            showError("Please enter school year");
            return false;
        }
        
        // Validate at least one complete item
        boolean hasValidItem = false;
        for (ItemRow row : itemRows) {
            if (row.isValid()) {
                hasValidItem = true;
                break;
            }
        }
        if (!hasValidItem) {
            showError("Please add at least one complete item");
            return false;
        }
        
        return true;
    }

    private void saveToFirebase(Map<String, Object> data) {
        new Thread(() -> {
            try {
                DatabaseReference ref = FirebaseDatabase.getInstance()
                        .getReference("transactions");
                
                String key = ref.push().getKey();
                ref.child(key).setValueAsync(data).get();
                
                Platform.runLater(() -> {
                    showSuccessDialog();
                });
                
            } catch (Exception e) {
                Platform.runLater(() -> {
                    showError("Failed to submit: " + e.getMessage());
                });
                e.printStackTrace();
            }
        }).start();
    }

    private void showSuccessDialog() {
        Stage dialog = new Stage();
        dialog.setTitle("Success");
        
        VBox content = new VBox(20);
        content.setAlignment(Pos.CENTER);
        content.setPadding(new Insets(30));
        content.setStyle("-fx-background-color: white;");
        
        Label message = new Label("Your form has been submitted.");
        message.setStyle("-fx-font-size: 16px; -fx-text-fill: #333333;");
        
        Button continueBtn = new Button("Continue");
        continueBtn.setStyle("-fx-background-color: #E8A020; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 30; -fx-background-radius: 5;");
        continueBtn.setOnAction(e -> {
            dialog.close();
            SceneManager.navigate(continueBtn, "/com/libtrack/home.fxml", "LibTrack", 900, 600);
        });
        
        content.getChildren().addAll(message, continueBtn);
        
        Scene scene = new Scene(content, 350, 200);
        dialog.setScene(scene);
        dialog.show();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Inner class for managing item rows
    private class ItemRow {
        private HBox container;
        private ComboBox<String> itemCombo;
        private TextField quantityField;
        private Label amountLabel;
        private Button removeButton;

        public ItemRow() {
            container = new HBox(10);
            container.setAlignment(Pos.CENTER_LEFT);
            container.setPadding(new Insets(5));
            container.setStyle("-fx-background-color: #f9f9f9; -fx-background-radius: 5;");

            // Item Description ComboBox
            itemCombo = new ComboBox<>();
            itemCombo.getItems().addAll(
                "Printing – Black Text",
                "Printing – Black Graphics",
                "Printing – Color Text",
                "Printing – Color Graphics",
                "Library Fine",
                "Outside Researcher Fee",
                "Alumni Fee",
                "Referral Letter"
            );
            itemCombo.setPromptText("Select item");
            itemCombo.setPrefWidth(250);
            itemCombo.setOnAction(e -> calculateAmount());

            // Quantity TextField
            quantityField = new TextField();
            quantityField.setPromptText("Qty");
            quantityField.setPrefWidth(80);
            quantityField.textProperty().addListener((obs, old, newVal) -> {
                if (!newVal.matches("\\d*")) {
                    quantityField.setText(newVal.replaceAll("[^\\d]", ""));
                }
                calculateAmount();
            });

            // Amount Label
            amountLabel = new Label("₱0.00");
            amountLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #C41E3A;");
            amountLabel.setPrefWidth(80);

            // Remove Button
            removeButton = new Button("✕");
            removeButton.setStyle("-fx-background-color: #C41E3A; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 5 10; -fx-background-radius: 3;");
            removeButton.setOnAction(e -> removeItemRow(this));

            container.getChildren().addAll(itemCombo, quantityField, amountLabel, removeButton);
        }

        private void calculateAmount() {
            String item = itemCombo.getValue();
            String qtyText = quantityField.getText().trim();
            
            if (item != null && !qtyText.isEmpty()) {
                try {
                    int qty = Integer.parseInt(qtyText);
                    double price = feePrices.getOrDefault(item, 0.0);
                    double amount = qty * price;
                    amountLabel.setText(String.format("₱%.2f", amount));
                    updateTotal();
                } catch (NumberFormatException e) {
                    amountLabel.setText("₱0.00");
                }
            } else {
                amountLabel.setText("₱0.00");
            }
        }

        public HBox getContainer() {
            return container;
        }

        public String getItemDescription() {
            return itemCombo.getValue();
        }

        public int getQuantity() {
            try {
                return Integer.parseInt(quantityField.getText().trim());
            } catch (NumberFormatException e) {
                return 0;
            }
        }

        public double getAmount() {
            String text = amountLabel.getText().replace("₱", "").replace(",", "");
            try {
                return Double.parseDouble(text);
            } catch (NumberFormatException e) {
                return 0.0;
            }
        }

        public boolean isValid() {
            return itemCombo.getValue() != null && !quantityField.getText().trim().isEmpty();
        }
    }
}