package com.libtrack.controllers;

import com.google.firebase.database.*;
import com.libtrack.session.SessionManager;
import com.libtrack.utils.SceneManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class EditController {

    // ── FXML ────────────────────────────────────────────────────
    @FXML private Label studentNameLabel;
    @FXML private Label studentNoLabel;
    @FXML private Label programLabel;
    @FXML private Label quantityInfoLabel;
    @FXML private Label schoolYearInfoLabel;
    @FXML private Label dateInfoLabel;
    @FXML private Label itemDescInfoLabel;

    @FXML private TextField chargeNoField;
    @FXML private TextField quantityField;
    @FXML private Label     descriptionLabel;
    @FXML private Label     amountLabel;
    @FXML private Label     statusLabel;

    // Internal state
    private int    unitPrice       = 0;
    private String transactionKey;

    // ── Fee lookup ──────────────────────────────────────────────
    private static int unitPriceFor(String desc) {
        if (desc == null) return 0;
        switch (desc) {
            case "Printing – Black Text":     return 4;
            case "Printing – Black Graphics": return 6;
            case "Printing – Color Text":     return 6;
            case "Printing – Color Graphics": return 15;
            case "Library Fine":              return 10;
            case "Outside Researcher Fee":    return 50;
            case "Alumni Fee":                return 50;
            case "Referral Letter":           return 25;
            default:                          return 0;
        }
    }

    // ── Init ────────────────────────────────────────────────────
    @FXML
    public void initialize() {
        System.out.println("EditController initialized");

        transactionKey = AdminDashboardController.selectedTransactionKey;
        if (transactionKey == null) {
            statusLabel.setText("Error: no transaction selected.");
            statusLabel.setStyle("-fx-text-fill: #C41E3A;");
            return;
        }

        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("transactions/" + transactionKey);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snap) {
                if (!snap.exists()) {
                    Platform.runLater(() -> {
                        statusLabel.setText("Transaction not found.");
                        statusLabel.setStyle("-fx-text-fill: #C41E3A;");
                    });
                    return;
                }

                String fullName    = str(snap, "fullName");
                String studentNo   = str(snap, "studentNo");
                String programYear = str(snap, "programYear");
                String schoolYear  = str(snap, "schoolYear");
                String txDate      = str(snap, "transactionDate");
                String itemDesc    = str(snap, "itemDescription");
                String chargeNo    = str(snap, "chargeNo");
                String qtyStr      = str(snap, "quantity");

                unitPrice = unitPriceFor(itemDesc);

                Platform.runLater(() -> {
                    // Read-only info
                    studentNameLabel.setText(fullName);
                    studentNoLabel.setText(studentNo);
                    programLabel.setText(programYear);
                    quantityInfoLabel.setText(qtyStr);
                    schoolYearInfoLabel.setText(schoolYear);
                    dateInfoLabel.setText(txDate);
                    itemDescInfoLabel.setText(itemDesc);

                    // Editable fields
                    chargeNoField.setText(chargeNo);
                    quantityField.setText(qtyStr);
                    descriptionLabel.setText(itemDesc);
                    amountLabel.setText("₱" + calc(qtyStr));

                    // Live amount update as qty changes
                    quantityField.textProperty().addListener((o, ov, nv) ->
                            amountLabel.setText("₱" + calc(nv)));
                });
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("Edit load error: " + error.getMessage());
                Platform.runLater(() -> {
                    statusLabel.setText("Failed to load.");
                    statusLabel.setStyle("-fx-text-fill: #C41E3A;");
                });
            }
        });
    }

    private int calc(String qtyStr) {
        try { return Integer.parseInt(qtyStr.trim()) * unitPrice; }
        catch (NumberFormatException e) { return 0; }
    }

    // ── Apply ───────────────────────────────────────────────────
    @FXML
    private void handleApply() {
        String chargeNo = chargeNoField.getText().trim();
        String qtyStr   = quantityField.getText().trim();

        if (chargeNo.isEmpty()) {
            statusLabel.setText("Please enter a Charge No.");
            statusLabel.setStyle("-fx-text-fill: #C41E3A;");
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(qtyStr);
            if (quantity <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            statusLabel.setText("Quantity must be a positive number.");
            statusLabel.setStyle("-fx-text-fill: #C41E3A;");
            return;
        }

        int amount = quantity * unitPrice;

        // Audit trail fields
        Map<String, Object> updates = new HashMap<>();
        updates.put("chargeNo",            chargeNo);
        updates.put("quantity",            quantity);
        updates.put("amount",             amount);
        updates.put("status",             "finalized");
        updates.put("adminHandler",       SessionManager.getAdminEmail());
        updates.put("lastTouchTimestamp", LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss")));

        statusLabel.setText("Saving...");
        statusLabel.setStyle("-fx-text-fill: #2E7D32;");

        FirebaseDatabase.getInstance()
                .getReference("transactions/" + transactionKey)
                .updateChildren(updates, (error, reference) -> {
                    Platform.runLater(() -> {
                        if (error != null) {
                            statusLabel.setText("✗ Save failed.");
                            statusLabel.setStyle("-fx-text-fill: #C41E3A;");
                        } else {
                            System.out.println("✓ Transaction updated: " + transactionKey);
                            statusLabel.setText("✓ Saved successfully.");
                            statusLabel.setStyle("-fx-text-fill: #2E7D32;");

                            // Auto back to dashboard after 1.2s
                            new Thread(() -> {
                                try { Thread.sleep(1200); } catch (InterruptedException ignored) {}
                                Platform.runLater(() ->
                                        SceneManager.navigate(statusLabel,
                                                "/com/libtrack/admin-dashboard.fxml",
                                                "LibTrack - Admin Dashboard", 1200, 700));
                            }).start();
                        }
                    });
                });
    }

    // ── Back ────────────────────────────────────────────────────
    @FXML
    private void handleBack() {
        SceneManager.navigate(statusLabel, "/com/libtrack/admin-dashboard.fxml",
                "LibTrack - Admin Dashboard", 1200, 700);
    }

    private String str(DataSnapshot s, String key) {
        Object v = s.child(key).getValue();
        return v != null ? v.toString() : "";
    }
}