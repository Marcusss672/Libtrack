package com.libtrack.controllers;

import com.libtrack.utils.SceneManager;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.Node;

public class Dpaconsentcontroller {

    @FXML
    public void initialize() {
        System.out.println("DpaConsentController initialized");
    }

    @FXML
    private void handleYes(ActionEvent event) {
        System.out.println("DPA Consent: User agreed");
        // Navigate to student input form
        SceneManager.navigate((Node) event.getSource(), 
                "/com/libtrack/student-form.fxml",
                "LibTrack - Student Form", 900, 600);
    }

    @FXML
    private void handleNo(ActionEvent event) {
        System.out.println("DPA Consent: User declined");
        // Return to home screen
        SceneManager.navigate((Node) event.getSource(), 
                "/com/libtrack/home.fxml",
                "LibTrack", 900, 600);
    }
}