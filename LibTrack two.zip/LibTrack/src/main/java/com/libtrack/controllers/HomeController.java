package com.libtrack.controllers;

import com.libtrack.utils.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class HomeController {

    @FXML private Button studentBtn;
    @FXML private Button adminBtn;

    @FXML
    public void initialize() {
        System.out.println("HomeController initialized");
    }

    @FXML
    private void handleStudentClick() {
        System.out.println("Student clicked");
        // Student side — will be built next
        SceneManager.navigate(studentBtn, "/com/libtrack/dpa-consent.fxml",
                "LibTrack", 900, 600);
    }

    @FXML
    private void handleAdminClick() {
        System.out.println("Admin clicked -> Login");
        SceneManager.navigate(adminBtn, "/com/libtrack/login.fxml",
                "LibTrack", 900, 600);
    }
}