package com.libtrack.controllers;

import com.google.firebase.database.*;
import com.libtrack.session.SessionManager;
import com.libtrack.utils.SceneManager;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.beans.property.SimpleStringProperty;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class AdminDashboardController {

    // ── FXML ────────────────────────────────────────────────────
    @FXML private DatePicker fromDate;
    @FXML private DatePicker toDate;
    @FXML private ComboBox<String> viewTypeCombo;
    @FXML private ComboBox<String> itemDescCombo;
    @FXML private TableView<TransactionRow> transactionTable;

    @FXML private TableColumn<TransactionRow, String> colName;
    @FXML private TableColumn<TransactionRow, String> colStudentNo;
    @FXML private TableColumn<TransactionRow, String> colProgram;
    @FXML private TableColumn<TransactionRow, String> colTerm;
    @FXML private TableColumn<TransactionRow, String> colSchoolYear;
    @FXML private TableColumn<TransactionRow, String> colDate;
    @FXML private TableColumn<TransactionRow, String> colItemDesc;
    @FXML private TableColumn<TransactionRow, String> colAmount;
    @FXML private TableColumn<TransactionRow, String> colAdminHandler;
    @FXML private TableColumn<TransactionRow, HBox>   colAction;

    // ── Static: passes selected key to EditController ──────────
    public static String selectedTransactionKey = null;

    // ── Init ────────────────────────────────────────────────────
    @FXML
    public void initialize() {
        System.out.println("AdminDashboardController initialized");

        // Default dates
        toDate.setValue(LocalDate.now());
        fromDate.setValue(LocalDate.now().minusDays(30));
        viewTypeCombo.getSelectionModel().selectFirst();
        itemDescCombo.getSelectionModel().selectFirst();

        // Bind columns
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colStudentNo.setCellValueFactory(new PropertyValueFactory<>("studentNo"));
        colProgram.setCellValueFactory(new PropertyValueFactory<>("programYear"));
        colTerm.setCellValueFactory(new PropertyValueFactory<>("term"));
        colSchoolYear.setCellValueFactory(new PropertyValueFactory<>("schoolYear"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("transactionDate"));
        colItemDesc.setCellValueFactory(new PropertyValueFactory<>("itemDescription"));
        colAmount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        colAdminHandler.setCellValueFactory(new PropertyValueFactory<>("adminHandler"));

        // Action column: Edit button per row
        colAction.setCellFactory(col -> new TableCell<>() {
            final Button editBtn = new Button("Edit");
            {
                editBtn.setStyle("dashboard-btn-edit");
                editBtn.setOnAction(e -> {
                    TransactionRow row = getTableView().getItems().get(getIndex());
                    selectedTransactionKey = row.getFirebaseKey();
                    System.out.println("Edit -> key: " + selectedTransactionKey);
                    SceneManager.navigate(editBtn, "/com/libtrack/edit.fxml",
                            "LibTrack - Edit Transaction", 1200, 700);
                });
            }

            @Override
            protected void updateItem(HBox item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : editBtn);
            }
        });

        // Load on open
        loadTransactions();
    }

    // ── Filter button handlers ──────────────────────────────────
    @FXML
    private void handleLoadByDate() { loadTransactions(); }

    @FXML
    private void handleLoadByItem() { loadTransactions(); }

    // ── Firebase pull ───────────────────────────────────────────
    private void loadTransactions() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("transactions");

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                List<TransactionRow> rows = new ArrayList<>();
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MM/dd/yyyy");

                for (DataSnapshot child : snapshot.getChildren()) {
                    String key          = child.getKey();
                    String fullName     = str(child, "fullName");
                    String studentNo    = str(child, "studentNo");
                    String programYear  = str(child, "programYear");
                    String term         = str(child, "term");
                    String schoolYear   = str(child, "schoolYear");
                    String itemDesc     = str(child, "itemDescription");
                    String amount       = str(child, "amount");
                    String adminHandler = str(child, "adminHandler");
                    String txDate       = str(child, "transactionDate");

                    // Date filter
                    if (fromDate.getValue() != null && toDate.getValue() != null && txDate != null && !txDate.isEmpty()) {
                        try {
                            LocalDate d = LocalDate.parse(txDate, fmt);
                            if (d.isBefore(fromDate.getValue()) || d.isAfter(toDate.getValue())) continue;
                        } catch (Exception ignored) {}
                    }

                    // Item description filter
                    String sel = itemDescCombo.getValue();
                    if (sel != null && !sel.equals("All Transactions") && !sel.equals(itemDesc)) continue;

                    rows.add(new TransactionRow(key, fullName, studentNo, programYear, term,
                            schoolYear, txDate, itemDesc, amount, adminHandler));
                }

                Platform.runLater(() -> {
                    transactionTable.setItems(FXCollections.observableList(rows));
                    System.out.println("Loaded " + rows.size() + " transactions");
                });
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("Load error: " + error.getMessage());
            }
        });
    }

    private String str(DataSnapshot s, String key) {
        Object v = s.child(key).getValue();
        return v != null ? v.toString() : "";
    }

    // ── TransactionRow bean ─────────────────────────────────────
    public static class TransactionRow {
        private final String firebaseKey;
        private final SimpleStringProperty fullName, studentNo, programYear, term,
                schoolYear, transactionDate, itemDescription, amount, adminHandler;

        public TransactionRow(String firebaseKey, String fullName, String studentNo,
                              String programYear, String term, String schoolYear,
                              String transactionDate, String itemDescription,
                              String amount, String adminHandler) {
            this.firebaseKey      = firebaseKey;
            this.fullName         = new SimpleStringProperty(fullName);
            this.studentNo        = new SimpleStringProperty(studentNo);
            this.programYear      = new SimpleStringProperty(programYear);
            this.term             = new SimpleStringProperty(term);
            this.schoolYear       = new SimpleStringProperty(schoolYear);
            this.transactionDate  = new SimpleStringProperty(transactionDate);
            this.itemDescription  = new SimpleStringProperty(itemDescription);
            this.amount           = new SimpleStringProperty(amount);
            this.adminHandler     = new SimpleStringProperty(adminHandler);
        }

        public String getFirebaseKey()       { return firebaseKey; }
        public String getFullName()          { return fullName.get(); }
        public String getStudentNo()         { return studentNo.get(); }
        public String getProgramYear()       { return programYear.get(); }
        public String getTerm()              { return term.get(); }
        public String getSchoolYear()        { return schoolYear.get(); }
        public String getTransactionDate()   { return transactionDate.get(); }
        public String getItemDescription()   { return itemDescription.get(); }
        public String getAmount()            { return amount.get(); }
        public String getAdminHandler()      { return adminHandler.get(); }
    }
}