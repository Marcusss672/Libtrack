package com.libtrack.controllers;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserRecord;
import com.google.firebase.database.*;
import com.libtrack.session.SessionManager;
import com.libtrack.utils.SceneManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import org.mindrot.jbcrypt.BCrypt;

public class LoginController {

    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;
    @FXML private Label statusLabel;

    @FXML
    public void initialize() {
        System.out.println("LoginController initialized");
        statusLabel.setText("");
        statusLabel.setVisible(false);
    }

    @FXML
    private void handleLogin() {
        String email = emailField.getText().trim();
        String password = passwordField.getText();

        // Validate input
        if (email.isEmpty() || password.isEmpty()) {
            showStatus("Please enter both email and password", "red");
            return;
        }

        // Disable button during login
        loginButton.setDisable(true);
        showStatus("Logging in...", "blue");

        // Perform authentication in background thread
        new Thread(() -> {
            try {
                // Get user by email from Firebase Auth
                UserRecord userRecord = FirebaseAuth.getInstance().getUserByEmail(email);
                String uid = userRecord.getUid();

                // Check if user is an admin in database
                DatabaseReference adminRef = FirebaseDatabase.getInstance()
                        .getReference("admins/" + uid);

                adminRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        if (!snapshot.exists()) {
                            Platform.runLater(() -> {
                                showStatus("Access denied: Not an admin account", "red");
                                loginButton.setDisable(false);
                            });
                            return;
                        }

                        // Get stored password hash
                        String storedHash = snapshot.child("passwordHash").getValue(String.class);
                        
                        if (storedHash == null) {
                            Platform.runLater(() -> {
                                showStatus("Error: Invalid admin configuration", "red");
                                loginButton.setDisable(false);
                            });
                            return;
                        }

                        // Verify password
                        if (BCrypt.checkpw(password, storedHash)) {
                            // Login successful
                            SessionManager.saveSession(uid, email);
                            
                            Platform.runLater(() -> {
                                showStatus("Login successful!", "green");
                                
                                // Navigate to admin dashboard
                                SceneManager.navigate(loginButton, 
                                        "/com/libtrack/admin-dashboard.fxml",
                                        "LibTrack - Admin Dashboard", 
                                        1280, 720);
                            });
                        } else {
                            Platform.runLater(() -> {
                                showStatus("Invalid password", "red");
                                loginButton.setDisable(false);
                            });
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Platform.runLater(() -> {
                            showStatus("Database error: " + error.getMessage(), "red");
                            loginButton.setDisable(false);
                        });
                    }
                });

            } catch (Exception e) {
                Platform.runLater(() -> {
                    showStatus("Login failed: " + e.getMessage(), "red");
                    loginButton.setDisable(false);
                    e.printStackTrace();
                });
            }
        }).start();
    }

    @FXML
    private void handleBack(MouseEvent event) {
        System.out.println("Back to home");
        SceneManager.navigate((javafx.scene.Node) event.getSource(), 
                "/com/libtrack/home.fxml",
                "LibTrack", 900, 600);
    }

    private void showStatus(String message, String color) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: " + color + ";");
        statusLabel.setVisible(true);
    }
}