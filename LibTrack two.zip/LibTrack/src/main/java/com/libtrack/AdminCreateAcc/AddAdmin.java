package com.libtrack.AdminCreateAcc;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserRecord;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.libtrack.security.FirebaseInitializer;
import org.mindrot.jbcrypt.BCrypt;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class AddAdmin {
    
    public static void main(String[] args) {
        try {
            System.out.println("=== Firebase Admin Account Creator ===\n");
            
            // Initialize Firebase
            System.out.println("Initializing Firebase...");
            FirebaseInitializer.initialize();
            System.out.println("✓ Firebase initialized\n");
            
            Scanner scanner = new Scanner(System.in);
            
            System.out.print("Enter admin email: ");
            String email = scanner.nextLine().trim();
            
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            
            if (email.isEmpty() || password.isEmpty()) {
                System.err.println("✗ Email and password cannot be empty!");
                scanner.close();
                System.exit(1);
                return;
            }
            
            // Step 1: Create user in Firebase Authentication
            System.out.println("\nStep 1: Creating user in Firebase Authentication...");
            String uid;
            try {
                UserRecord.CreateRequest request = new UserRecord.CreateRequest()
                        .setEmail(email)
                        .setPassword(password)
                        .setEmailVerified(false)
                        .setDisabled(false);

                UserRecord userRecord = FirebaseAuth.getInstance().createUser(request);
                uid = userRecord.getUid();
                
                System.out.println("✓ User created in Authentication");
                System.out.println("  UID: " + uid);
            } catch (Exception e) {
                System.err.println("✗ Failed to create user in Authentication: " + e.getMessage());
                scanner.close();
                System.exit(1);
                return;
            }
            
            // Step 2: Generate password hash
            System.out.println("\nStep 2: Generating password hash...");
            String passwordHash = BCrypt.hashpw(password, BCrypt.gensalt(10));
            System.out.println("✓ Password hashed");
            
            // Step 3: Save to Realtime Database
            System.out.println("\nStep 3: Saving to Firebase Realtime Database...");
            
            Map<String, Object> adminData = new HashMap<>();
            adminData.put("email", email);
            adminData.put("passwordHash", passwordHash);
            adminData.put("createdAt", System.currentTimeMillis());
            
            DatabaseReference ref = FirebaseDatabase.getInstance()
                    .getReference("admins");
            
            // Use CountDownLatch to wait for completion
            CountDownLatch latch = new CountDownLatch(1);
            final boolean[] success = {false};
            
            System.out.println("Writing to database path: admins/" + uid);
            
            ref.child(uid).setValue(adminData, new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(DatabaseError error, DatabaseReference ref) {
                    if (error != null) {
                        System.err.println("\n✗ Error saving to database!");
                        System.err.println("Error: " + error.getMessage());
                    } else {
                        success[0] = true;
                        System.out.println("✓ Saved to database");
                    }
                    latch.countDown();
                }
            });
            
            // Wait for completion
            System.out.println("Waiting for database write...");
            boolean completed = latch.await(15, TimeUnit.SECONDS);
            
            if (!completed) {
                System.err.println("\n✗ Timeout waiting for database write");
                scanner.close();
                System.exit(1);
                return;
            }
            
            if (!success[0]) {
                System.err.println("\n✗ Database write failed");
                scanner.close();
                System.exit(1);
                return;
            }
            
            System.out.println("\n✓ Admin account created successfully!");
            System.out.println("══════════════════════════════════");
            System.out.println("Email: " + email);
            System.out.println("Admin UID: " + uid);
            System.out.println("══════════════════════════════════");
            System.out.println("\nYou can now login with these credentials.");
            
            scanner.close();
            Thread.sleep(1000);
            System.exit(0);
            
        } catch (Exception e) {
            System.err.println("\n✗ Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}